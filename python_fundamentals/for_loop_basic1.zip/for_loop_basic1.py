# task 1 
for x in range(150):
         print(x)
# task 2  
for  y in range(5,1000,5):
          print(y)
# task 3 
for z in range(1,100):
        if z%5 ==0 :
            print("coding")
        if z%10 ==0 :
            print("coding dojo") 
#task 4 
sum = 0
for odd in range(0,50):
    if odd%2 !=0: 
        sum = odd+ sum
        print(sum)

#task 5  :
for ye in range(2018,0,-4):
         print (ye)        
                                

# task 5 : 
low_num = 2 
mut = 3 
high_num= 10
for n in range(low_num,high_num):
     if n%mut ==0 :
         print(n)        

